# eMithran CAD-to-Casting Architecture

**Purpose:** Principal-engineer implementation pack for extending the existing eMithran sand-casting module into a STEP-to-engineering-review-to-BOM/routing/costing workflow.

## Scope decisions

- Casting process: sand casting only (initial release).
- CAD input: STEP / STP.
- Outputs: material BOM, process/tooling BOM, routing, detailed costing.
- Automation: automated analysis with mandatory engineer review.
- Existing implementation: extend the C++ casting worker and NestJS backend; do not rewrite without evidence.

## Documents

| File | Purpose |
|---|---|
| `01-product-scope-and-principles.md` | Product scope, goals, non-goals and engineering principles |
| `02-system-architecture.md` | Components, boundaries, data flow and deployment |
| `03-cad-ingestion-and-geometry.md` | STEP ingestion, geometry extraction and validation |
| `04-casting-engineering-and-methoding.md` | DFM, parting, cores, gating, risers and moulding |
| `05-bom-routing-and-costing.md` | BOM structures, routing, material balance and costing |
| `06-data-model-and-database.md` | Proposed entities, relationships, constraints and migrations |
| `07-api-contracts.md` | NestJS API proposal and payload contracts |
| `08-review-workflow-and-audit.md` | Engineer review, overrides, revisioning and approvals |
| `09-validation-and-accuracy.md` | Test strategy, benchmark corpus and production validation |
| `10-implementation-roadmap.md` | Milestones, dependencies and review gates |
| `11-repository-integration-plan.md` | Existing-repository audit and integration instructions |
| `12-claude-principal-engineer-instructions.md` | Operating instructions for Claude Code |
| `13-definition-of-done.md` | Acceptance criteria and release checklist |
| `14-open-decisions-and-risks.md` | Decisions that must be resolved before implementation |

## How to use

1. Copy this folder into the repository, preferably under `docs/architecture/cad-to-casting/`.
2. Give Claude Code `12-claude-principal-engineer-instructions.md` and ask it to read all documents.
3. Require the repository audit milestone before implementation.
4. Require a written plan and explicit approval at every milestone.
5. Treat all example values and formulas as illustrative until verified against foundry standards, plant data and real production cases.

## Important status note

This pack is a target architecture, not evidence that any proposed module, API, table or feature already exists. Claude must inspect the repository and reconcile this design with the actual codebase before making changes.
