# 02 — Target System Architecture

## 1. Architectural approach

Use a modular NestJS business application plus an independently scalable C++ engineering worker. Do not create a microservice per calculation module. Separate responsibilities through clear module and contract boundaries first.

## 2. Logical components

### Frontend
- CAD upload and revision selection.
- 3D viewer and geometry overlays.
- DFM findings.
- Methoding review.
- BOM and routing review.
- Cost breakdown and assumptions.
- Approval and audit history.

### NestJS application
- Authentication and authorization.
- Project and CAD revision lifecycle.
- Job orchestration.
- Plant/material master data.
- Engineering workflow.
- BOM and routing generation.
- Cost calculations.
- Review, approval and quotation release.
- API contracts and audit events.

### C++ engineering worker
- STEP import and validation.
- Geometry normalization and measurements.
- Feature extraction.
- Wall thickness and draft analysis.
- Parting and undercut analysis.
- Cavity/core candidate analysis.
- Methoding geometry and calculations where already implemented.

### Infrastructure
- Relational database for transactional data.
- Object storage for original STEP files and derived geometry/artifacts.
- Job queue for long-running analysis.
- Observability for worker execution, failures and resource usage.

Reuse current repository infrastructure after audit. Do not introduce PostgreSQL, Redis, BullMQ, S3 or another dependency merely because this document mentions them.

## 3. Component boundaries

| Concern | Owner |
|---|---|
| CAD file bytes and immutable storage | CAD/document module |
| Geometry/topology calculations | C++ worker |
| Engineering rule configuration | Casting domain |
| Plant configuration and pricing | NestJS domain/master data |
| Methoding approval | Engineering workflow |
| BOM generation | Manufacturing BOM module |
| Routing | Manufacturing routing module |
| Costing | Costing module |
| Quote release | Commercial workflow |

## 4. Pipeline

`UPLOAD -> CAD_VALIDATION -> GEOMETRY_ANALYSIS -> DFM_ANALYSIS -> METHODING_PROPOSAL -> ENGINEER_REVIEW -> BOM_GENERATION -> ROUTING_GENERATION -> COST_ESTIMATION -> COST_REVIEW -> QUOTE_RELEASE`

Each stage must:
- Have a stable input/output contract.
- Persist status and error details.
- Be idempotent for the same input revision and configuration.
- Record implementation/version identifiers.
- Be restartable without duplicating business records.
- Reject stale or incompatible upstream revisions.

## 5. Worker contract

Prefer a versioned, schema-validated request/response contract. Avoid coupling NestJS to C++ internal structs.

Worker request should include:
- `job_id`
- `cad_revision_id`
- immutable object reference or controlled local file reference
- requested analysis stages
- unit policy
- material-independent geometry options
- worker contract version

Worker response should include:
- `job_id`
- `contract_version`
- `worker_version`
- stage status
- geometry measurements with units
- feature references
- DFM findings
- warnings/errors
- artifact references
- provenance metadata

The worker must not decide customer pricing, plant energy rates, labour rates or commercial approval.

## 6. Scaling and reliability

- Run CAD jobs asynchronously.
- Apply per-tenant and per-plant concurrency limits.
- Enforce file size, execution time and memory limits.
- Isolate untrusted CAD parsing in a restricted worker process/container.
- Use job leases/heartbeats and retry only retryable failures.
- Make outputs idempotent and persist stage checkpoints where appropriate.
- Store large geometry artifacts outside relational rows.
- Record worker timing and peak memory.

## 7. Security

- Validate file type by content, not filename extension alone.
- Scan uploaded files where supported.
- Use tenant-scoped authorization for CAD, BOM and cost records.
- Do not expose storage paths or worker filesystem paths.
- Restrict worker network access.
- Avoid executing embedded macros or external references.
- Audit downloads, overrides and approvals.
