# 06 — Data Model and Database Design

## 1. Design requirements

- Reconcile with existing ORM, naming and tenant model before creating migrations.
- Use existing primary-key conventions.
- Scope every record to tenant/customer/plant as appropriate.
- Use immutable revision records for CAD, methoding, BOM and estimates.
- Use foreign keys and database constraints for referential integrity.
- Store large CAD and mesh artifacts in object storage.
- Store structured measurements and provenance in the database.
- Store timestamps in UTC.
- Persist units and currency explicitly.

## 2. Logical entity map

```text
casting_projects
  ├── cad_documents
  │     └── cad_revisions
  │           └── geometry_analyses
  │                 ├── geometry_features
  │                 └── dfm_findings
  ├── casting_method_plans
  │     ├── parting_plans
  │     ├── core_plans
  │     ├── gating_plans
  │     ├── riser_plans
  │     └── mould_plans
  ├── manufacturing_boms
  │     └── bom_revisions
  │           └── bom_items
  ├── process_routings
  │     └── routing_operations
  ├── cost_estimates
  │     ├── cost_lines
  │     └── cost_assumptions
  └── engineering_reviews
        └── approval_events
```

## 3. Proposed entities and key fields

### `casting_projects`
- `id`
- `tenant_id`
- `project_number`
- `customer_id`
- `plant_id`
- `part_number`
- `description`
- `status`
- `created_by`
- `created_at`

### `cad_documents`
- `id`
- `project_id`
- `original_filename`
- `format`
- `storage_key`
- `sha256`
- `uploaded_by`
- `uploaded_at`

### `cad_revisions`
- `id`
- `document_id`
- `revision_code`
- `unit_system`
- `source_checksum`
- `status`
- `created_at`

### `geometry_analyses`
- `id`
- `cad_revision_id`
- `worker_version`
- `algorithm_version`
- `contract_version`
- `volume_value`
- `volume_unit`
- `surface_area_value`
- `surface_area_unit`
- `solid_count`
- `status`
- `completed_at`

### `geometry_features`
- `id`
- `analysis_id`
- `feature_key`
- `feature_type`
- `geometry_reference`
- `properties_json`
- `detector_version`

### `dfm_findings`
- `id`
- `analysis_id`
- `rule_code`
- `rule_version`
- `severity`
- `measured_value`
- `measured_unit`
- `threshold_value`
- `threshold_unit`
- `geometry_reference`
- `recommendation`
- `blocks_approval`

### `casting_method_plans`
- `id`
- `analysis_id`
- `material_grade_id`
- `plant_id`
- `revision`
- `status`
- `rule_set_version`
- `created_at`

### Methoding detail entities
- `parting_plans`: candidate direction, selected direction, geometry reference, evidence.
- `core_plans`: core key, volume, process, recipe, quantity per mould, status.
- `gating_plans`: gating configuration, ratio, dimensions, mass, calculation evidence.
- `riser_plans`: riser configuration, count, volume, feeding method and evidence.
- `mould_plans`: box configuration, envelope volume, cavity count and sand system.

### BOM entities
- `manufacturing_boms`: project and method plan linkage.
- `bom_revisions`: revision, status, created by, approval state.
- `bom_items`: item type, material/resource reference, quantity, unit, quantity basis, provenance, override linkage.

### Routing entities
- `process_routings`: BOM revision, routing revision and status.
- `routing_operations`: operation code, sequence, resource, setup time, cycle time, time unit, batch basis and source.

### Costing entities
- `cost_estimates`: BOM revision, plant, pricing snapshot, currency, total, status and calculation version.
- `cost_lines`: category, quantity, unit, rate, rate unit, amount, currency, source.
- `cost_assumptions`: assumption code, value, unit, source, approval status.

### Review entities
- `engineering_reviews`: reviewed entity/revision, reviewer, decision, comment and timestamp.
- `approval_events`: actor, action, exact entity revision, prior/new status, timestamp and audit metadata.

## 4. Master data

Reuse existing master data if available. Otherwise design:
- `material_grades`
- `material_properties`
- `plant_process_parameters`
- `casting_rules`
- `charge_recipes`
- `sand_systems`
- `core_processes`
- `material_prices`
- `energy_tariffs`
- `resource_rates`
- `machine_resources`
- `operation_templates`
- `overhead_policies`

All effective-dated commercial and process parameters should be versioned.

## 5. Important constraints

- Unique revision number per parent.
- Unique BOM item key where business rules require it.
- Non-negative quantities and rates unless an explicit adjustment type permits otherwise.
- Valid unit and currency references.
- No approval of a stale revision.
- No quote release when required blockers exist.
- Foreign-key linkage from estimate to exact BOM revision.
- Prevent mutation of approved/released records through application policy and database safeguards where practical.

## 6. JSON fields

Use JSON only for variable engineering properties and structured geometry metadata. Do not hide core relational concepts such as material, quantity, unit, status, plant or revision inside opaque JSON.

## 7. Migration strategy

1. Inspect current schema and ORM.
2. Map existing entities.
3. Identify reusable tables.
4. Propose additive migrations.
5. Review indexes and tenant isolation.
6. Test migration up/down in disposable environment.
7. Back up before production migration.
8. Never rename/drop existing production fields as part of the initial feature without a separate migration plan.
