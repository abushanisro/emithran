# 08 — Engineering Review, Approval and Audit

## 1. State model

Suggested project/analysis states:
- `DRAFT`
- `CAD_UPLOADED`
- `CAD_VALIDATING`
- `CAD_INVALID`
- `GEOMETRY_ANALYZING`
- `GEOMETRY_ANALYZED`
- `DFM_ANALYZED`
- `METHODING_PROPOSED`
- `ENGINEERING_REVIEW_PENDING`
- `ENGINEERING_REJECTED`
- `METHODING_APPROVED`
- `BOM_GENERATED`
- `BOM_REVIEW_PENDING`
- `BOM_APPROVED`
- `ROUTING_GENERATED`
- `COST_CALCULATED`
- `COST_REVIEW_PENDING`
- `COST_APPROVED`
- `QUOTE_RELEASED`
- `SUPERSEDED`

Keep job execution status separate from business approval status.

## 2. Review gates

### Gate A — Methoding
Reviewer sees:
- CAD model and revision.
- Geometry report.
- DFM findings.
- Parting candidates.
- Core candidates and proposed cores.
- Gating and riser proposal.
- Mould configuration.
- Missing inputs and assumptions.

Possible decisions:
- Approve.
- Reject with comments.
- Request changes.
- Apply audited override.

### Gate B — BOM and routing
Reviewer sees:
- Material BOM.
- Process/tooling BOM.
- Quantity basis and formula.
- Routing sequence.
- Plant resource assumptions.
- Missing master data.

### Gate C — Cost and quotation
Reviewer sees:
- Detailed cost lines.
- Rate and price snapshots.
- Currency.
- Yield and rejection assumptions.
- Tooling amortization.
- Commercial margin/markup policy if applicable.
- Missing inputs and estimate limitations.

## 3. Override record

Every override must preserve:
- Original calculated value.
- New value.
- Unit.
- Reason code.
- Free-text explanation.
- Actor.
- Timestamp.
- Affected entity and revision.
- Source calculation.
- Approval decision.

Do not overwrite the original worker result.

## 4. Approval invariants

- Reviewer must have the required role and plant/tenant access.
- Reviewer must approve the exact revision displayed.
- Stale revisions cannot be approved.
- Changes after approval create a new revision or invalidate downstream approvals.
- Quote release requires all mandatory gates.
- Approval events are append-only from the application perspective.
- Administrative corrections must also be audited.

## 5. Role examples

- CAD uploader.
- Foundry/process engineer.
- BOM reviewer.
- Cost estimator.
- Commercial approver.
- Administrator.

Map these to existing eMithran roles rather than creating a parallel identity system.

## 6. Audit event example

```json
{
  "entity_type": "core_plan",
  "entity_id": "core_plan_example",
  "revision": 2,
  "action": "QUANTITY_OVERRIDDEN",
  "actor_id": "user_example",
  "before": {"quantity": 2, "unit": "piece"},
  "after": {"quantity": 3, "unit": "piece"},
  "reason": "ENGINEERING_REVIEW",
  "comment": "Additional support core required by approved method",
  "timestamp": "UTC timestamp"
}
```

Example only. Use actual application identity and timestamp formats.
