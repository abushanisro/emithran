# 07 — API Contracts

## 1. Conventions

Follow existing NestJS API versioning, DTO, validation, error and authentication conventions. The routes below are proposed logical endpoints; adjust to existing route structure.

Prefix example: `/api/v1/casting`

Use:
- DTO validation.
- Tenant/plant authorization.
- Idempotency keys for job creation and quote release where appropriate.
- Pagination for collections.
- Consistent error envelopes.
- Optimistic concurrency/revision checks.
- Asynchronous job status for CAD processing.

## 2. Project and CAD

| Method | Route | Purpose |
|---|---|---|
| POST | `/projects` | Create casting project |
| GET | `/projects/:projectId` | Retrieve project |
| POST | `/projects/:projectId/cad` | Upload STEP |
| GET | `/projects/:projectId/cad` | List CAD revisions |
| GET | `/cad/:revisionId` | Retrieve CAD revision metadata |
| POST | `/cad/:revisionId/analyze` | Queue analysis |
| GET | `/jobs/:jobId` | Retrieve job status |
| GET | `/cad/:revisionId/analysis` | Retrieve geometry analysis |
| GET | `/cad/:revisionId/dfm` | Retrieve DFM findings |

## 3. Methoding

| Method | Route | Purpose |
|---|---|---|
| POST | `/projects/:projectId/methoding` | Generate method proposal |
| GET | `/methoding/:methodPlanId` | Retrieve proposal |
| PATCH | `/methoding/:methodPlanId/parting` | Submit parting override |
| PATCH | `/methoding/:methodPlanId/cores` | Submit core override |
| PATCH | `/methoding/:methodPlanId/gating` | Submit gating override |
| PATCH | `/methoding/:methodPlanId/risers` | Submit riser override |
| POST | `/methoding/:methodPlanId/validate` | Validate proposal |
| POST | `/methoding/:methodPlanId/reviews` | Submit review decision |

## 4. BOM, routing and costing

| Method | Route | Purpose |
|---|---|---|
| POST | `/methoding/:methodPlanId/bom/generate` | Generate BOM revision |
| GET | `/projects/:projectId/bom` | List/retrieve BOM |
| GET | `/bom/:bomRevisionId` | Retrieve exact BOM revision |
| POST | `/bom/:bomRevisionId/approve` | Approve BOM |
| GET | `/projects/:projectId/routing` | Retrieve routing |
| POST | `/bom/:bomRevisionId/routing/generate` | Generate routing |
| POST | `/projects/:projectId/costing/calculate` | Create cost estimate |
| GET | `/costing/:estimateId` | Retrieve estimate |
| GET | `/costing/:estimateId/assumptions` | Retrieve assumptions |
| POST | `/costing/:estimateId/approve` | Approve estimate |
| POST | `/costing/:estimateId/release` | Release quotation |

## 5. Example analysis request

```http
POST /api/v1/casting/cad/{revisionId}/analyze
Idempotency-Key: <unique-client-key>
Content-Type: application/json
```

```json
{
  "stages": ["geometry", "features", "dfm"],
  "options": {
    "healing_policy": "safe_only"
  }
}
```

Example response:

```json
{
  "job_id": "job_example",
  "cad_revision_id": "cad_revision_example",
  "status": "queued",
  "contract_version": "1"
}
```

## 6. Example geometry response

```json
{
  "analysis_id": "analysis_example",
  "status": "completed",
  "geometry": {
    "volume": {"value": 12000000, "unit": "mm3"},
    "surface_area": {"value": 1800000, "unit": "mm2"},
    "solid_count": 1,
    "source_unit": "mm"
  },
  "mass": {
    "status": "pending_material_selection"
  },
  "provenance": {
    "worker_version": "recorded-at-runtime",
    "algorithm_version": "recorded-at-runtime"
  }
}
```

Values are illustrative only.

## 7. Error categories

- `INVALID_CAD_FILE`
- `UNSUPPORTED_STEP_CONTENT`
- `INVALID_GEOMETRY`
- `MISSING_MATERIAL_GRADE`
- `MISSING_PLANT_CONFIGURATION`
- `METHODING_REVIEW_REQUIRED`
- `BOM_VALIDATION_FAILED`
- `MISSING_PRICE_CONFIGURATION`
- `STALE_REVISION`
- `APPROVAL_REQUIRED`
- `JOB_RESOURCE_LIMIT_EXCEEDED`

## 8. API invariants

- Analysis references an immutable CAD revision.
- Methoding references an exact geometry analysis.
- BOM references an approved methoding revision.
- Routing references an exact BOM revision.
- Costing references an exact BOM and routing revision.
- Release references exact approved revisions and pricing snapshot.
- Any upstream change invalidates downstream approval eligibility.
