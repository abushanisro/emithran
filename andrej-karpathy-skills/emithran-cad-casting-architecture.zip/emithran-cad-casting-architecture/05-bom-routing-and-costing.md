# 05 — Manufacturing BOM, Routing and Costing

## 1. Three linked manufacturing structures

### Material BOM
Consumables and materials consumed in production:
- Charge constituents.
- Foundry returns.
- Moulding sand.
- Core sand and binder.
- Coatings.
- Filters, sleeves, chills and other selected consumables.

### Process/tooling BOM
Manufacturing assets and methoding components:
- Pattern.
- Core boxes.
- Mould boxes.
- Fixtures.
- Core assemblies.
- Gating/riser tooling.
- Reusable and per-piece items classified separately.

### Routing
Sequence of operations and resources:
- Pattern/tooling preparation.
- Coremaking and curing.
- Moulding.
- Core setting and mould closing.
- Melting and alloy adjustment.
- Pouring.
- Cooling/solidification.
- Shakeout.
- Fettling.
- Shot blasting.
- Heat treatment if required.
- Machining if required.
- Inspection and dispatch.

## 2. Metal mass balance

Keep these quantities separate:
- Net finished casting mass.
- Gross casting mass including machining allowance, where applicable.
- Gating mass.
- Riser mass.
- Total poured metal mass.
- Internal return mass.
- External scrap/revert mass.
- Fresh charge mass.
- Melting loss and recovery.

Illustrative identities:

`poured_mass = gross_casting_mass + gating_mass + riser_mass + other_poured_features`

`fresh_charge_mass` must be solved from the charge recipe, available returns, recovery and alloy requirements. It is not always equal to `poured_mass / one generic yield`.

Define casting yield and melting recovery separately. Do not double-count return metal or charge constituents.

## 3. Sand and core quantities

Mould sand:
- Derive mould envelope volume.
- Subtract relevant cavity and occupied volumes.
- Apply plant-specific sand bulk density/compaction assumptions.
- Distinguish reusable sand circulation from fresh sand additions and losses.

Core sand:
- Use confirmed core geometry volume.
- Apply the relevant core sand density/system.
- Calculate binder and additives using the configured recipe.
- Distinguish core mass from binder mass.

Do not price total circulating sand as if it were all newly purchased sand. Model make-up, loss, reclamation and reuse where data exists.

## 4. Consumables

Only include consumables required by the selected method and plant:
- Coatings.
- Filters.
- Sleeves.
- Exothermic materials.
- Chills.
- Chaplets.
- Release agents.
- Refractory and furnace consumables.

Each line must state whether quantity is geometry-derived, rule-derived, recipe-derived or manually configured.

## 5. Routing model

Each operation should capture:
- Operation code and sequence.
- Work centre/resource.
- Setup time.
- Cycle time per unit or per batch.
- Batch size.
- Labour requirement.
- Machine occupancy.
- Energy driver.
- Yield/rejection relationship.
- Source template and override.
- Unit and time basis.

Avoid mixing per-piece, per-batch and per-mould quantities.

## 6. Costing model

Suggested categories:
- Metal charge.
- Mould materials and preparation.
- Core materials and coremaking.
- Melting energy and conversion.
- Pouring.
- Shakeout and fettling.
- Shot blasting.
- Heat treatment.
- Machining.
- Inspection.
- Tooling amortization.
- Labour.
- Machine/resource rates.
- Factory overhead.
- Packaging and logistics if in commercial scope.

Cost line formula:

`line_amount = normalized_quantity * snapshotted_rate`

Where the quantity and rate share compatible units and the rate has an explicit effective period/currency.

Batch and unit costs:

`batch_cost = sum(validated cost lines)`

`unit_cost = batch_cost / saleable_quantity`

The saleable quantity must account for the configured yield/rejection model without applying the same loss twice.

## 7. Pricing snapshots

Every estimate must snapshot:
- Material price.
- Charge recipe.
- Energy tariff.
- Labour rate.
- Machine rate.
- Plant parameters.
- Overhead policy.
- Currency and conversion rate, if applicable.
- Effective dates.
- Source and version.

A future price update must not silently change a previously approved estimate.

## 8. Missing inputs

Represent missing values explicitly. Examples:
- `MISSING_MATERIAL_PRICE`
- `MISSING_ENERGY_RATE`
- `MISSING_PLANT_SAND_SYSTEM`
- `MISSING_CORE_PROCESS`
- `UNAPPROVED_METHODING`
- `UNVALIDATED_YIELD_ASSUMPTION`

A quote may be marked incomplete or blocked according to policy. Never fabricate a price or process parameter.

## 9. BOM provenance

Every BOM line should include:
- Quantity and unit.
- Quantity basis.
- Source geometry/methoding reference.
- Formula/rule identifier and version.
- Plant configuration reference.
- Material/resource master reference.
- Evidence status.
- Override linkage, if applicable.
