# 10 — Implementation Roadmap and Review Gates

## Delivery strategy

Implement one end-to-end vertical slice. Do not parallelize all modules before contracts, data model and validation fixtures exist.

## M0 — Repository and architecture audit

Tasks:
- Inspect repository tree and current branch state.
- Inspect existing casting worker and API contracts.
- Inspect Open CASCADE version and STEP support.
- Inspect current database/ORM, queue, storage and viewer.
- Review current casting design document and relevant PRs.
- Identify implemented versus planned functionality.
- Map existing entities and files to this architecture.
- Identify gaps, risks and dependencies.

Deliverables:
- `repository-audit.md`
- current-to-target component map
- proposed migrations/API changes
- test baseline
- implementation plan

**STOP for owner approval. No feature implementation before approval.**

## M1 — STEP ingestion and geometry

Tasks:
- Upload and immutable revision.
- STEP parser validation.
- Unit normalization.
- Solid/shell handling.
- Volume, area, bounding box and centroid.
- Worker contract and async job.
- Geometry regression fixtures.

Deliverable: validated geometry report.

**STOP for review.**

## M2 — DFM

Tasks:
- Wall thickness.
- Draft.
- S5 undercuts.
- S7 face references and audited overrides.
- Core candidate classification.
- CAD viewer references.

Deliverable: engineer-reviewable DFM report.

**STOP for review.**

## M3 — Methoding

Tasks:
- Parting candidate evaluation.
- Core arrangement.
- Gating integration.
- Riser/feeding proposal.
- Mould configuration.
- Methoding validation.

Deliverable: proposed methoding revision.

**STOP for review.**

## M4 — BOM

Tasks:
- Material BOM.
- Core/mould sand.
- Binder and consumables.
- Charge mass balance.
- Process/tooling BOM.
- Provenance for each item.

Deliverable: draft BOM revision.

**STOP for review.**

## M5 — Routing and costing

Tasks:
- Operation templates.
- Plant resources and rates.
- Setup/cycle times.
- Material and conversion costs.
- Energy and labour.
- Yield/rejection treatment.
- Price snapshots and missing-input handling.

Deliverable: draft routing and cost estimate.

**STOP for review.**

## M6 — Approval UX and release

Tasks:
- Methoding approval.
- BOM approval.
- Cost approval.
- Overrides.
- Audit trail.
- Exact revision binding.
- Quote release.

Deliverable: complete engineer-reviewed workflow.

**STOP for review.**

## M7 — Real-part validation

Tasks:
- Collect representative real-part corpus.
- Compare calculations against trusted geometry and actual production.
- Analyze variance.
- Calibrate plant-specific rules.
- Publish evidence and limitations.

Deliverable: production validation report.

## Dependencies

- M1 precedes reliable geometry-driven M2.
- M2 and M3 precede final methoding BOM.
- M3 precedes final BOM.
- BOM and routing precede costing.
- Approval/revision model should be designed in M0, not bolted on at M6.
- M7 depends on real production records.

## Release strategy

Use feature flags or staged rollout if supported by the current platform. Do not expose incomplete calculations as approved quotations.
