# 04 — Sand-Casting DFM and Methoding

## 1. Methoding is a proposal, not an automatic truth

CAD geometry describes the finished shape. It does not uniquely determine the foundry's manufacturing method. The system must produce candidate methods, expose assumptions and require engineer approval.

## 2. DFM modules

### Draft
- Evaluate candidate draw directions.
- Determine faces with insufficient draft against plant/material rules.
- Show affected geometry and measured angle.
- Distinguish geometric warning from foundry-approved exception.

### Thin walls
- Consume geometry engine thickness regions.
- Compare with material/process/plant-specific thresholds.
- Report local value, region, rule and recommendation.

### Undercuts
For each candidate mould opening direction:
1. Evaluate visibility/accessibility and geometric obstruction.
2. Identify connected obstructed regions.
3. Distinguish undercut from a cavity that can be formed by an alternative mould arrangement.
4. Propose possible core, loose-piece or revised parting solutions.
5. Expose evidence and let engineer decide.

Do not assume every undercut requires a core.

### Parting
- Evaluate feasible draw directions and candidate parting surfaces.
- Consider projected area, geometry complexity, undercuts and mould arrangement.
- Measure parting line where method permits.
- Mark fallback estimates explicitly.
- Retain candidate alternatives and engineer selection.

### Core analysis
Distinguish:
- Geometric cavity candidate.
- Accessible cavity.
- Mould-formable region.
- Core-required candidate.
- Engineer-confirmed core.

For confirmed cores, capture:
- Core identifier and geometry reference.
- Volume and surface area.
- Core process/system.
- Core sand/binder recipe.
- Core prints/support assumptions.
- Core box/tooling requirements.
- Quantity per mould and per production batch.

## 3. Gating

Reuse existing `sand-gating.ts` and worker functionality after audit.

Inputs may include:
- Alloy and pouring temperature range.
- Casting weight.
- Target pouring time.
- Gating ratio.
- Flow assumptions.
- Number and location of ingates.
- Sprue/runner geometry.
- Filter and choke configuration.

Outputs:
- Sprue, runner and ingate geometry/quantities.
- Gating metal volume and mass.
- Flow/velocity calculations.
- Pouring-time estimate.
- Assumptions and warnings.

Do not treat a ratio alone as a complete validated gating design.

## 4. Risers and feeding

Create a dedicated module. Initial engineering methods may include:
- Hot-spot and thermal modulus estimation.
- Chvorinov-type solidification-time relationships where assumptions are valid.
- Feeding distance and directional solidification rules.
- Riser modulus and efficiency.
- Chills and sleeve recommendations.

Complex castings require simulation and/or foundry engineer validation. Keep calculated, rule-based and simulation-derived results distinguishable.

## 5. Mould configuration

Capture:
- Cope/drag arrangement.
- Mould box dimensions and type.
- Number of cavities per mould.
- Pattern arrangement.
- Mould envelope and cavity volumes.
- Core placement and support.
- Moulding process and sand system.
- Mould preparation assumptions.

Start with single-cavity assumptions only if the plant configuration explicitly selects them. Multi-cavity optimisation is a later feature.

## 6. Plant-specific rule configuration

Rules must be versioned and scoped by:
- Plant.
- Casting process.
- Alloy/material grade.
- Moulding/core process.
- Effective date.
- Approval status.

A rule must define units, applicability, source/reference, threshold, severity and version.

## 7. Methoding review output

For each proposed feature, provide:
- Proposed value/geometry.
- Source measurements.
- Rule and algorithm version.
- Assumptions.
- Alternatives, if available.
- Warnings and blockers.
- Engineer decision and comment.
