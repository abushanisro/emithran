# 13 — Definition of Done and Release Checklist

## CAD ingestion
- [ ] STEP/STP upload works with authorization and limits.
- [ ] Original file is preserved and checksummed.
- [ ] Units are detected and normalized.
- [ ] Solids/shells/multiple bodies are handled.
- [ ] Invalid geometry is rejected or explicitly flagged.
- [ ] Healing is controlled and auditable.
- [ ] Geometry results are versioned and tested.

## Geometry and DFM
- [ ] Volume and area validated against reference fixtures.
- [ ] Mass is calculated only after material selection.
- [ ] Wall thickness has documented limitations and tests.
- [ ] Draft findings identify affected geometry.
- [ ] Undercut findings distinguish candidate solutions.
- [ ] Core candidates are not silently treated as confirmed cores.
- [ ] Face references are revision-scoped.
- [ ] DFM rules are versioned and plant/material aware.

## Methoding
- [ ] Parting proposal is reviewable.
- [ ] Core plan is reviewable.
- [ ] Gating calculation has documented inputs and assumptions.
- [ ] Riser/feeding proposal has engineering evidence.
- [ ] Mould configuration is explicit.
- [ ] Engineer approval is mandatory.

## BOM and routing
- [ ] Material BOM is separate from process/tooling BOM.
- [ ] Reusable tooling is distinguished from consumables.
- [ ] Metal mass balance is consistent.
- [ ] Casting yield and melting recovery are distinct.
- [ ] Returns and scrap are not double counted.
- [ ] Sand reuse/reclamation is represented where data exists.
- [ ] Every line has quantity, unit and provenance.
- [ ] Routing has operation/resource/time basis.
- [ ] Batch and per-piece quantities are not mixed.

## Costing
- [ ] Material prices are versioned.
- [ ] Plant parameters and resource rates are snapshotted.
- [ ] Currency and rate units are explicit.
- [ ] Energy, labour and machine costs have defined drivers.
- [ ] Tooling amortization policy is explicit.
- [ ] Missing required inputs block or mark estimate incomplete.
- [ ] Cost lines are reproducible.
- [ ] Cost estimate references exact BOM/routing revisions.

## Review and audit
- [ ] Methoding review exists.
- [ ] BOM review exists.
- [ ] Cost review exists.
- [ ] Overrides preserve before/after values and reasons.
- [ ] Stale revisions cannot be approved.
- [ ] Approval events are auditable.
- [ ] Quote release requires all required approvals.
- [ ] Released quote cannot silently change.

## Reliability and security
- [ ] CAD processing has time and memory limits.
- [ ] Worker failures are structured and observable.
- [ ] Jobs are idempotent and safely retryable.
- [ ] Tenant and plant access is enforced.
- [ ] Original CAD and derived artifacts are access-controlled.
- [ ] CI tests pass.
- [ ] Regression tests cover existing casting functionality.

## Production validation
- [ ] Real-part benchmark corpus exists.
- [ ] Geometry references are documented.
- [ ] Actual material consumption is compared.
- [ ] Actual cycle times are compared.
- [ ] Actual cost variance is measured.
- [ ] Known limitations are published.
- [ ] Production validation is not claimed from synthetic tests alone.
