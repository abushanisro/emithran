# 03 — STEP Ingestion and Geometry Intelligence

## 1. Input contract

Initial formats: STEP AP203/AP214/AP242 where supported by the selected Open CASCADE version. Confirm exact support in the repository and dependency version.

Preserve the original upload byte-for-byte. Any healing or normalization must produce a derived artifact and never overwrite the original.

## 2. Ingestion sequence

1. Authenticate and authorize upload.
2. Enforce file-size and content-type limits.
3. Store original file and calculate cryptographic checksum.
4. Create immutable CAD document revision.
5. Queue validation job.
6. Parse STEP and identify units.
7. Identify solids, shells, faces and disconnected bodies.
8. Validate topology and geometry.
9. Apply safe healing only under explicit policy.
10. Extract geometry metrics.
11. Persist structured results and derived artifacts.
12. Return reviewable validation report.

## 3. Required geometry measurements

| Measurement | Unit / representation | Notes |
|---|---|---|
| Volume | mm³ internally or canonical SI | Record source unit and conversion |
| Surface area | mm² or SI | Separate total and classified area where possible |
| Bounding box | mm per axis | Record coordinate frame |
| Centroid | 3D coordinate | Record coordinate frame |
| Inertia tensor | mass/volume basis | State density assumptions |
| Solid count | integer | Identify disconnected bodies |
| Face/edge/vertex counts | integer | Useful diagnostics |
| Minimum/maximum local thickness | mm | Algorithm and sampling metadata required |
| Hole/cylinder candidates | feature records | Detection is not necessarily manufacturing intent |

Do not calculate mass until material density is known. Geometry volume and density-derived mass must remain distinguishable.

## 4. Geometry validity states

- `VALID`
- `VALID_WITH_WARNINGS`
- `HEALING_REQUIRED`
- `INVALID`
- `UNSUPPORTED`
- `ANALYSIS_FAILED`

A failed or ambiguous model must not continue silently into BOM generation.

## 5. Feature extraction

Potential features:
- Planar, cylindrical, conical and spherical faces.
- Through-hole and blind-hole candidates.
- Cavities and pockets.
- Thin regions.
- Ribs and bosses.
- Fillets and chamfers.
- Candidate machining surfaces.
- Candidate core regions.

Each feature needs:
- Stable feature identifier within an analysis revision.
- Feature type.
- Geometry reference.
- Measured properties and units.
- Detection method/version.
- Evidence and limitations.

Do not promise stable face IDs across unrelated CAD revisions. Use revision-scoped references and geometric matching only as an explicit, reviewable mapping.

## 6. Wall thickness

Use a robust local thickness method suitable for curved and non-planar geometry, such as ray-based opposing-surface analysis with appropriate sampling or a validated medial-axis approach.

Requirements:
- Document sampling strategy and tolerances.
- Detect ambiguous/self-near regions.
- Retain point/region references.
- Report local minima and connected thin regions.
- Include algorithm version and error limitations.
- Validate against known benchmark geometries.

A planar face-to-face shortcut is not sufficient for general geometry.

## 7. Unit policy

Choose one canonical internal unit system, preferably SI, or a rigorously documented mm/kg engineering convention. Every persisted quantity must have a unit. Conversions must occur at system boundaries and be tested.

## 8. Geometry acceptance tests

Include:
- STEP in millimetres and inches.
- Single solid.
- Multiple solids.
- Open shell.
- Invalid topology.
- Large and small coordinate magnitudes.
- Rotated coordinate frames.
- Curved thin-wall geometry.
- Repeated upload/checksum behavior.
- Geometry healing on/off.
- Known reference volume and area.

Record reference source and allowed numerical tolerance for each fixture.
