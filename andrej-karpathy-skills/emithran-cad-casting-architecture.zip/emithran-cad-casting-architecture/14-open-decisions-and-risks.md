# 14 — Open Decisions and Risks

This document prevents assumptions from becoming hidden implementation requirements.

## 1. Decisions requiring repository audit

| Question | Required evidence |
|---|---|
| Which Open CASCADE version is installed? | Build files and dependency lock |
| Does worker already parse STEP? | Source and tests |
| What is worker transport? | Existing protocol |
| Which ORM/database is used? | Schema and package configuration |
| Which queue is used? | Existing job implementation |
| Where are CAD files stored? | Storage module |
| What viewer/overlay format exists? | Frontend integration |
| What are actual API conventions? | Controllers and DTOs |
| What is current SH2 status? | Branch/PR/main verification |
| What is PR #153/#154 status? | GitHub/remote evidence |

## 2. Foundry decisions requiring qualified review

- Supported alloy grades and applicable standards.
- Density and material property sources.
- Minimum wall thickness and draft rules by alloy/process/plant.
- Parting direction and moulding system.
- Core process and binder recipes.
- Gating design method and permissible flow velocities.
- Riser/feeding design method.
- Sand system, compaction and reclamation assumptions.
- Casting yield and melting recovery.
- Charge recipe and return-metal treatment.
- Pouring temperature and time ranges.
- Plant energy and resource rates.
- Operation times and rejection assumptions.
- Inspection and quality requirements.

## 3. Technical risks

### Geometry ambiguity
STEP topology and face identity can change between CAD revisions. Use revision-scoped geometry references and explicit mapping.

### Methoding is not uniquely determined
Several foundry methods can produce the same finished geometry. Expose alternatives and require engineer selection.

### Simulation complexity
Filling and solidification simulation is a significant engineering capability. Do not imply a simple heuristic is equivalent to validated simulation.

### Quantity and mass-balance errors
Incorrect separation of casting yield, melting recovery, returns and fresh charge can materially distort BOM and cost.

### Plant variability
A calculation calibrated for one foundry may not generalize to another. Scope rules and rates to plant/process/material.

### Cost snapshot drift
If estimates reference live prices rather than immutable snapshots, old quotations become irreproducible.

### Unsafe CAD parsing
CAD files are untrusted input. Isolate parsing, enforce resource limits and restrict worker permissions.

## 4. Questions to close during M0/M1

1. Is the existing worker already built around Open CASCADE?
2. What STEP schemas and units are currently supported?
3. Does the platform already have material/plant master data?
4. Is there an existing BOM or routing model to extend?
5. Which sand moulding process is the first target at the pilot foundry?
6. Which alloy grades will be in the first benchmark?
7. Which real STEP parts and production records can be used?
8. Who is the qualified foundry engineer approving rules and methoding?
9. What is the expected production batch-size range?
10. What is the commercial costing boundary: ex-works, machining included, or delivered?

## 5. Risk policy

Any unresolved high-severity engineering or data risk must be recorded in the milestone report. Do not hide it behind a generic confidence score or automatic fallback.
