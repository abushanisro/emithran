# 11 — Existing Repository Integration Plan

## 1. Repository facts to verify

Prior conversation notes mention:
- Existing C++ casting worker.
- NestJS backend integration.
- `parting.cpp`.
- `cores.cpp`.
- `sand-cores.ts`.
- `sand-gating.ts`.
- `sand-dfm.ts`.
- SH1 cure/strip-time work.
- SH2 hot-box heating energy branch.
- SH3 gating visualization.
- SH4 gating metal-velocity work.
- S5 undercut analysis not yet implemented.
- S7 face references/overrides not confirmed.
- PR #153 and PR #154.

These are historical notes, not guaranteed current repository state. Verify each fact using git and source code before acting.

## 2. Mandatory audit

Inspect:
- Git status, branch and remotes.
- Current main branch commit.
- PR state and merge commits if GitHub access is available.
- Worker source tree and build system.
- C++ dependencies and Open CASCADE availability.
- Worker request/response protocol.
- NestJS modules, controllers, DTOs and services.
- ORM entities and migrations.
- Queue/job infrastructure.
- Object storage.
- Existing CAD viewer and overlay format.
- Test suites and CI commands.
- Design documentation.

Do not run destructive git commands. Do not discard or overwrite local user changes.

## 3. Integration mapping

| Existing module | Target responsibility |
|---|---|
| `parting.cpp` | Parting analysis |
| `cores.cpp` | Cavity/core analysis |
| `sand-cores.ts` | Core BOM and coremaking cost |
| `sand-gating.ts` | Gating quantities and costs |
| `sand-dfm.ts` | DFM rule orchestration |
| Existing worker | Geometry and engineering execution |
| Existing NestJS casting module | APIs and workflow |
| Existing viewer | Geometry overlays and review |

Inspect actual paths and naming before editing.

## 4. Suggested logical additions

Only add these if equivalent functionality does not already exist:
- STEP import/validation module.
- Geometry metrics module.
- Wall-thickness module.
- Undercut module.
- Riser/feeding module.
- Mould configuration module.
- Metal mass-balance service.
- Material BOM generator.
- Process/tooling BOM generator.
- Routing generator.
- Cost provenance service.
- Review/approval module.

## 5. PR discipline

- Work on a dedicated feature branch.
- Keep changes scoped to one milestone.
- Do not retarget, merge or close unrelated PRs without authorization.
- Run relevant worker and backend tests.
- Report exact commands and results.
- Do not report a test as passing if it was not run.
- Do not merge unless explicitly authorized.
- Update design docs and changelog/status.
- Stop for review at each milestone.

## 6. First output from coding agent

Before coding, provide:
1. Repository map.
2. Existing feature inventory.
3. PR/branch status if available.
4. Existing architecture diagram.
5. Database/ORM inventory.
6. Existing tests and baseline.
7. Gaps against this target architecture.
8. Proposed file-level implementation plan.
9. Risks and unresolved decisions.
10. Exact next milestone and approval request.
