# 01 — Product Scope and Engineering Principles

## 1. Product objective

Build an eMithran workflow that transforms an uploaded STEP model into an engineer-reviewable sand-casting manufacturing plan, material BOM, process/tooling BOM, routing and plant-specific cost estimate.

The system must preserve traceability from every generated quantity and cost line back to:
- CAD revision and geometry evidence;
- engineering rule and algorithm version;
- methoding decision;
- plant configuration and price snapshot;
- engineer override, if any.

## 2. Initial scope

| Dimension | Initial decision |
|---|---|
| Process | Sand casting |
| CAD | STEP / STP |
| Outputs | Material BOM + process/tooling BOM + routing + costing |
| Automation | Automated proposal, mandatory engineer approval |
| Backend | Existing NestJS application |
| Engineering worker | Existing C++ worker |
| Geometry kernel | Open CASCADE, subject to repository/dependency audit |
| Database | Reuse existing database, likely PostgreSQL; verify |
| Queue/storage | Reuse existing infrastructure; verify |

## 3. Explicit non-goals for first release

- Investment casting, die casting, gravity casting or permanent-mould casting.
- Unattended production release.
- AI-generated engineering quantities without deterministic evidence.
- Automatic tooling design suitable for manufacture without engineer approval.
- Universal accuracy guarantees.
- Automatic inference of alloy grade from geometry.
- Full CFD/solidification simulation unless separately scoped and validated.
- Broad repository refactoring unrelated to this workflow.

## 4. Core principles

1. **Physics before AI:** geometry and quantity calculations must be deterministic and testable.
2. **Evidence before confidence:** show the calculation source and status, not unsupported confidence percentages.
3. **Plant-aware calculations:** rules and parameters must be configurable by plant, alloy and process.
4. **Explicit missing inputs:** never silently substitute zero, defaults or guessed rates for required values.
5. **Immutable approved revisions:** a new CAD, methoding, BOM or price revision must not mutate a released quote.
6. **Human approval:** methoding, BOM and cost require the configured engineering/commercial approvals.
7. **Mass balance:** avoid double counting charge metal, poured metal, returns and scrap.
8. **Units are mandatory:** quantities must carry canonical units and conversions.
9. **Reproducibility:** retain algorithm, rule, configuration and price versions for each estimate.
10. **Incremental delivery:** complete one vertical slice and validate it before broad expansion.

## 5. User workflow

1. Create casting project.
2. Upload STEP file and create immutable CAD revision.
3. Validate file and extract geometry.
4. Select alloy/material grade, plant, quantity and required specifications.
5. Run DFM and methoding analysis.
6. Review warnings and proposed method.
7. Engineer approves or revises methoding.
8. Generate BOM and routing.
9. Calculate cost using plant and price snapshots.
10. Engineer/commercial reviewer approves estimate.
11. Release quotation against exact approved revisions.

## 6. Product outputs

### Engineering report
- CAD validation result.
- Geometry measurements.
- DFM findings and CAD locations.
- Proposed parting, cores, gating, risers and mould configuration.
- Assumptions and unresolved inputs.

### Material BOM
- Metal charge constituents.
- Foundry returns and recoverable materials.
- Moulding sand.
- Core sand and binder.
- Coatings and process consumables.
- Filters, sleeves, chills and other methoding-specific consumables.

### Process/tooling BOM
- Pattern and core-box assets.
- Mould boxes and fixtures.
- Core assemblies.
- Gating/riser assemblies.
- Reusable versus per-piece items clearly classified.

### Routing
- Operation sequence.
- Resource/work centre.
- Setup and cycle time.
- Batch basis and quantity basis.
- Labour, machine and energy drivers.

### Cost estimate
- Material cost.
- Conversion cost.
- Energy.
- Labour.
- Machine/resource time.
- Finishing and machining.
- Quality/inspection.
- Overhead and tooling amortization.
- Missing-input and assumption report.
