# 09 — Validation, Accuracy and Benchmark Strategy

## 1. Do not claim production accuracy without production evidence

Separate:
- Geometry correctness.
- Engineering methoding correctness.
- Consumption accuracy.
- Cost accuracy.

A precise volume calculation does not prove accurate casting yield, core selection, riser design or actual cost.

## 2. Validation levels

### L1 — Geometry verified
Compare worker results with trusted CAD measurements/reference models:
- Volume.
- Surface area.
- Bounding box.
- Centroid.
- Thickness on known geometries.
- Feature detection.

### L2 — Rule calculated
Verify each engineering rule with hand-worked examples and reviewed references.

### L3 — Engineer approved
Foundry engineer reviews methoding, BOM and assumptions.

### L4 — Production validated
Compare estimates with actual foundry consumption, times, yield, rejection and costs.

## 3. Benchmark corpus

Collect real parts and associated records:
1. Original STEP.
2. Drawing and revision.
3. Alloy/material grade.
4. Approved methoding.
5. Parting and core details.
6. Gating/riser details.
7. Actual poured and finished weights.
8. Actual sand and binder consumption.
9. Actual energy and labour.
10. Cycle times.
11. Rejection and yield.
12. Actual production cost.

Synthetic fixtures are useful for unit tests but must not be represented as real-production validation.

## 4. Geometry benchmark classes

- Simple solid.
- Hollow part.
- Multiple cavities.
- Multi-core part.
- Thin-wall part.
- Complex undercuts.
- Curved/organic geometry.
- Multiple bodies.
- Large/heavy casting.
- Invalid or incomplete model.

## 5. Metrics

Track:
- Absolute and relative volume error.
- Surface area error.
- Thickness error by region.
- Feature detection precision/recall where labels exist.
- Core count agreement with approved method.
- Poured metal mass error.
- Sand/core material quantity error.
- Operation time error.
- Unit cost variance.
- Missing-input rate.
- Engineer override rate.
- Job failure rate and worker resource use.

Define acceptable tolerances with engineering owners and benchmark evidence. Do not invent universal thresholds.

## 6. Evidence status taxonomy

- `GEOMETRY_VERIFIED`
- `RULE_CALCULATED`
- `PLANT_CONFIGURED`
- `ENGINEER_APPROVED`
- `PRODUCTION_VALIDATED`
- `MISSING_INPUT`
- `UNVERIFIED_ASSUMPTION`

## 7. Regression policy

Every bug fix and algorithm change must add a regression fixture where practical. Store expected outputs with tolerance and reference provenance. Compare results across worker versions before promoting to production.

## 8. Production monitoring

Monitor:
- STEP parse failures.
- Invalid geometry rate.
- Worker duration and memory.
- Retry rate.
- DFM warning distribution.
- Engineer rejection/override patterns.
- BOM variance.
- Cost variance against actuals.
